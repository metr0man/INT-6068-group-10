import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scene_creation import DroneScene

# 新增：导入RL模型和环境
from stable_baselines3 import PPO
from massive_single_drone_env import SingleDronePathPlanningEnv
import os

def generate_trajectory_with_model(model_path, max_steps=500):
    model = PPO.load(model_path)
    env = SingleDronePathPlanningEnv(env_id=0)
    obs, info = env.reset()
    trajectory = [env.scene.get_drone_position(env.drone_id)]
    for _ in range(max_steps):
        action, _ = model.predict(obs, deterministic=True)
        obs, reward, terminated, truncated, info = env.step(action)
        trajectory.append(env.scene.get_drone_position(env.drone_id))
        if terminated or truncated:
            break
    return trajectory, env.scene.targets, env.scene.obstacles

if __name__ == "__main__":
    use_model = True  # 设置为True则用RL模型轨迹，否则为静态场景
    model_path = os.path.join("models", "massive_single_drone_ppo_6000000_steps.zip")

    if use_model:
        trajectory, targets, obstacles = generate_trajectory_with_model(model_path, max_steps=500)
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')

        # 绘制障碍物（用立方体表示）
        for obs in obstacles:
            x, y, z = obs['position']
            l, w, h = obs['length'], obs['width'], obs['height']
            ax.bar3d(x - l/2, y - w/2, 0, l, w, h, color='r', alpha=0.4, shade=True)

        # 绘制轨迹
        traj = list(zip(*trajectory))
        ax.plot(traj[0], traj[1], traj[2], color='b', linewidth=2, label='Drone Trajectory')
        # 绘制起点
        ax.scatter(traj[0][0], traj[1][0], traj[2][0], color='c', s=100, label='Start')
        # 绘制终点
        ax.scatter(traj[0][-1], traj[1][-1], traj[2][-1], color='m', s=100, label='End')
        # 绘制目标点
        for tgt in targets:
            ax.scatter(tgt[0], tgt[1], tgt[2], color='g', s=80, label='Target')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title('RL模型轨迹可视化')
        ax.view_init(elev=30, azim=45)
        plt.tight_layout()
        plt.legend()
        plt.show()
    else:
        scene = DroneScene(gui=False)
        scene.create_obstacles()
        scene.create_targets()
        scene.create_drone()

        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')

        # 绘制障碍物（用立方体表示）
        for obs in scene.obstacles:
            x, y, z = obs['position']
            l, w, h = obs['length'], obs['width'], obs['height']
            ax.bar3d(x - l/2, y - w/2, 0, l, w, h, color='r', alpha=0.4, shade=True)

        # 绘制目标点
        for tgt in scene.targets:
            ax.scatter(tgt[0], tgt[1], tgt[2], color='g', s=80, label='Target')

        # 绘制起点
        ax.scatter(0, 0, 0, color='b', s=100, label='Start')

        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title('3D 场景障碍物与目标点分布预览')
        ax.view_init(elev=30, azim=45)
        plt.tight_layout()
        plt.show() 