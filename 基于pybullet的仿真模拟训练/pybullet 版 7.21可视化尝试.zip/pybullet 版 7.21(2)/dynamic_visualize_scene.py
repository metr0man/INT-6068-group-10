import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from scene_creation import DroneScene
import time
from matplotlib.animation import FuncAnimation

class DynamicSceneVisualizer:
    def __init__(self, scene):
        self.scene = scene
        self.drone_trajectory = []
        self.obstacle_trajectories = []
        self.current_time = 0
        
    def add_drone_position(self, position):
        """记录无人机位置"""
        self.drone_trajectory.append([self.current_time] + list(position))
        
    def add_obstacle_movement(self, obstacle_id, position):
        """记录障碍物位置"""
        if obstacle_id >= len(self.obstacle_trajectories):
            self.obstacle_trajectories.append([])
        self.obstacle_trajectories[obstacle_id].append([self.current_time] + list(position))
        
    def simulate_drone_path(self, targets, steps=100):
        """模拟无人机路径规划"""
        current_pos = np.array([0, 0, 2.5])
        self.add_drone_position(current_pos)
        
        for target in targets:
            target_pos = np.array(target)
            # 简单的直线路径，可以替换为更复杂的路径规划算法
            for i in range(steps):
                t = i / steps
                # 使用贝塞尔曲线或直线插值
                new_pos = current_pos + t * (target_pos - current_pos)
                self.current_time += 0.1
                self.add_drone_position(new_pos)
            current_pos = target_pos
            
    def simulate_obstacle_movement(self, num_moving_obstacles=5, duration=10):
        """模拟动态障碍物移动"""
        # 选择一些障碍物作为动态障碍物
        moving_obstacles = self.scene.obstacles[:num_moving_obstacles]
        
        for i, obs in enumerate(moving_obstacles):
            start_pos = np.array(obs['position'])
            # 随机移动方向和速度
            direction = np.random.uniform(-1, 1, 3)
            direction[2] = 0  # 保持在同一高度
            direction = direction / np.linalg.norm(direction)
            speed = np.random.uniform(0.5, 2.0)
            
            for t in np.linspace(0, duration, 50):
                new_pos = start_pos + direction * speed * t
                # 边界检查
                new_pos[0] = np.clip(new_pos[0], -50, 50)
                new_pos[1] = np.clip(new_pos[1], -50, 50)
                self.add_obstacle_movement(i, new_pos)
                
    def create_animation(self):
        """创建动画可视化"""
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # 设置坐标轴范围
        ax.set_xlim(-60, 60)
        ax.set_ylim(-60, 60)
        ax.set_zlim(0, 20)
        
        # 绘制静态障碍物
        for obs in self.scene.obstacles:
            x, y, z = obs['position']
            l, w, h = obs['length'], obs['width'], obs['height']
            ax.bar3d(x - l/2, y - w/2, 0, l, w, h, color='gray', alpha=0.3, shade=True)
        
        # 绘制目标点
        for tgt in self.scene.targets:
            ax.scatter(tgt[0], tgt[1], tgt[2], color='g', s=100, label='Target')
        
        # 绘制起点
        ax.scatter(0, 0, 0, color='b', s=100, label='Start')
        
        # 初始化动态元素
        drone_line, = ax.plot([], [], [], 'b-', linewidth=2, label='Drone Path')
        drone_point, = ax.plot([], [], [], 'bo', markersize=8)
        obstacle_points = []
        
        for i in range(len(self.obstacle_trajectories)):
            point, = ax.plot([], [], [], 'ro', markersize=6)
            obstacle_points.append(point)
        
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title('动态场景可视化 - 无人机轨迹与移动障碍物')
        ax.legend()
        
        def animate(frame):
            # 更新无人机位置
            if frame < len(self.drone_trajectory):
                drone_data = np.array(self.drone_trajectory[:frame+1])
                if len(drone_data) > 0:
                    drone_line.set_data(drone_data[:, 1], drone_data[:, 2])
                    drone_line.set_3d_properties(drone_data[:, 3])
                    drone_point.set_data([drone_data[-1, 1]], [drone_data[-1, 2]])
                    drone_point.set_3d_properties([drone_data[-1, 3]])
            
            # 更新动态障碍物位置
            for i, obs_traj in enumerate(self.obstacle_trajectories):
                if frame < len(obs_traj):
                    pos = obs_traj[frame]
                    obstacle_points[i].set_data([pos[1]], [pos[2]])
                    obstacle_points[i].set_3d_properties([pos[3]])
            
            return drone_line, drone_point, *obstacle_points
        
        # 创建动画
        anim = FuncAnimation(fig, animate, frames=min(len(self.drone_trajectory), 200), 
                           interval=50, blit=True, repeat=True)
        
        plt.tight_layout()
        plt.show()
        return anim

def main():
    # 创建场景
    scene = DroneScene(gui=False)
    scene.create_obstacles(num_obstacles=20)  # 减少障碍物数量以便观察
    scene.create_targets(num_targets=3)
    scene.create_drone()
    
    # 创建可视化器
    visualizer = DynamicSceneVisualizer(scene)
    
    # 模拟无人机路径
    targets = [tgt for tgt in scene.targets]
    visualizer.simulate_drone_path(targets, steps=50)
    
    # 模拟动态障碍物
    visualizer.simulate_obstacle_movement(num_moving_obstacles=3, duration=5)
    
    # 创建动画
    anim = visualizer.create_animation()
    
    print("动画已创建，显示中...")

if __name__ == "__main__":
    main() 