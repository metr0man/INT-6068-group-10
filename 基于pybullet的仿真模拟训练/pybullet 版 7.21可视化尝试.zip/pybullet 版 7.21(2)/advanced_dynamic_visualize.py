import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from scene_creation import DroneScene
import heapq
from matplotlib.animation import FuncAnimation

class PathPlanner:
    def __init__(self, scene):
        self.scene = scene
        self.grid_size = 2.0  # 网格大小
        self.grid_bounds = (-60, 60, -60, 60, 0, 20)
        
    def is_valid_position(self, pos):
        """检查位置是否有效（不碰撞）"""
        x, y, z = pos
        # 检查边界
        if not (self.grid_bounds[0] <= x <= self.grid_bounds[1] and
                self.grid_bounds[2] <= y <= self.grid_bounds[3] and
                self.grid_bounds[4] <= z <= self.grid_bounds[5]):
            return False
        
        # 检查与障碍物的碰撞
        for obs in self.scene.obstacles:
            ox, oy, _ = obs['position']
            l, w = obs['length'] / 2, obs['width'] / 2
            if (abs(x - ox) < l + 1.0) and (abs(y - oy) < w + 1.0):
                return False
        return True
    
    def get_neighbors(self, pos):
        """获取相邻位置"""
        x, y, z = pos
        neighbors = []
        for dx in [-self.grid_size, 0, self.grid_size]:
            for dy in [-self.grid_size, 0, self.grid_size]:
                for dz in [-self.grid_size, 0, self.grid_size]:
                    if dx == dy == dz == 0:
                        continue
                    new_pos = (x + dx, y + dy, z + dz)
                    if self.is_valid_position(new_pos):
                        neighbors.append(new_pos)
        return neighbors
    
    def heuristic(self, pos1, pos2):
        """启发式函数（欧几里得距离）"""
        return np.linalg.norm(np.array(pos1) - np.array(pos2))
    
    def a_star_path(self, start, goal):
        """A*路径规划"""
        open_set = [(0, start)]
        came_from = {}
        g_score = {start: 0}
        f_score = {start: self.heuristic(start, goal)}
        closed_set = set()
        
        while open_set:
            current_f, current = heapq.heappop(open_set)
            
            if current == goal:
                # 重建路径
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                return path[::-1]
            
            closed_set.add(current)
            
            for neighbor in self.get_neighbors(current):
                if neighbor in closed_set:
                    continue
                
                tentative_g = g_score[current] + self.heuristic(current, neighbor)
                
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + self.heuristic(neighbor, goal)
                    
                    if neighbor not in [item[1] for item in open_set]:
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))
        
        return None  # 没有找到路径

class AdvancedDynamicVisualizer:
    def __init__(self, scene):
        self.scene = scene
        self.path_planner = PathPlanner(scene)
        self.drone_trajectory = []
        self.obstacle_trajectories = []
        self.current_time = 0
        
    def plan_drone_path(self, targets):
        """使用A*算法规划无人机路径"""
        current_pos = (0, 0, 2.5)
        self.add_drone_position(current_pos)
        
        for target in targets:
            goal = tuple(target)
            path = self.path_planner.a_star_path(current_pos, goal)
            
            if path:
                # 沿路径移动
                for i, pos in enumerate(path):
                    self.current_time += 0.1
                    self.add_drone_position(pos)
                current_pos = goal
            else:
                # 如果A*失败，使用直线路径
                print(f"无法找到到目标 {goal} 的路径，使用直线路径")
                target_pos = np.array(goal)
                for i in range(50):
                    t = i / 50
                    new_pos = np.array(current_pos) + t * (target_pos - np.array(current_pos))
                    self.current_time += 0.1
                    self.add_drone_position(new_pos)
                current_pos = goal
    
    def simulate_complex_obstacle_movement(self, num_moving_obstacles=5, duration=10):
        """模拟复杂的动态障碍物移动"""
        moving_obstacles = self.scene.obstacles[:num_moving_obstacles]
        
        for i, obs in enumerate(moving_obstacles):
            start_pos = np.array(obs['position'])
            
            # 创建更复杂的运动模式
            if i % 3 == 0:
                # 圆周运动
                center = start_pos[:2]
                radius = np.random.uniform(5, 15)
                angular_speed = np.random.uniform(0.5, 1.5)
                
                for t in np.linspace(0, duration, 100):
                    angle = angular_speed * t
                    x = center[0] + radius * np.cos(angle)
                    y = center[1] + radius * np.sin(angle)
                    z = start_pos[2]
                    self.add_obstacle_movement(i, [x, y, z])
                    
            elif i % 3 == 1:
                # 正弦波运动
                amplitude = np.random.uniform(10, 20)
                frequency = np.random.uniform(0.5, 1.0)
                direction = np.random.uniform(0, 2*np.pi)
                
                for t in np.linspace(0, duration, 100):
                    x = start_pos[0] + amplitude * np.sin(frequency * t) * np.cos(direction)
                    y = start_pos[1] + amplitude * np.sin(frequency * t) * np.sin(direction)
                    z = start_pos[2]
                    self.add_obstacle_movement(i, [x, y, z])
                    
            else:
                # 随机游走
                current_pos = start_pos.copy()
                for t in np.linspace(0, duration, 100):
                    # 添加随机噪声
                    noise = np.random.normal(0, 0.5, 3)
                    noise[2] = 0  # 保持高度不变
                    current_pos += noise
                    
                    # 边界检查
                    current_pos[0] = np.clip(current_pos[0], -50, 50)
                    current_pos[1] = np.clip(current_pos[1], -50, 50)
                    
                    self.add_obstacle_movement(i, current_pos)
    
    def add_drone_position(self, position):
        """记录无人机位置"""
        self.drone_trajectory.append([self.current_time] + list(position))
        
    def add_obstacle_movement(self, obstacle_id, position):
        """记录障碍物位置"""
        if obstacle_id >= len(self.obstacle_trajectories):
            self.obstacle_trajectories.append([])
        self.obstacle_trajectories[obstacle_id].append([self.current_time] + list(position))
    
    def create_advanced_animation(self):
        """创建高级动画可视化"""
        fig = plt.figure(figsize=(14, 10))
        ax = fig.add_subplot(111, projection='3d')
        
        # 设置坐标轴范围
        ax.set_xlim(-60, 60)
        ax.set_ylim(-60, 60)
        ax.set_zlim(0, 20)
        
        # 绘制静态障碍物
        for obs in self.scene.obstacles:
            x, y, z = obs['position']
            l, w, h = obs['length'], obs['width'], obs['height']
            ax.bar3d(x - l/2, y - w/2, 0, l, w, h, color='gray', alpha=0.3, shade=True)
        
        # 绘制目标点
        for tgt in self.scene.targets:
            ax.scatter(tgt[0], tgt[1], tgt[2], color='g', s=100, label='Target')
        
        # 绘制起点
        ax.scatter(0, 0, 0, color='b', s=100, label='Start')
        
        # 初始化动态元素
        drone_line, = ax.plot([], [], [], 'b-', linewidth=3, label='Drone Path')
        drone_point, = ax.plot([], [], [], 'bo', markersize=10)
        obstacle_points = []
        obstacle_trails = []
        
        for i in range(len(self.obstacle_trajectories)):
            point, = ax.plot([], [], [], 'ro', markersize=8)
            trail, = ax.plot([], [], [], 'r-', alpha=0.5, linewidth=1)
            obstacle_points.append(point)
            obstacle_trails.append(trail)
        
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title('高级动态场景可视化 - A*路径规划与复杂动态障碍物')
        ax.legend()
        
        def animate(frame):
            # 更新无人机位置和轨迹
            if frame < len(self.drone_trajectory):
                drone_data = np.array(self.drone_trajectory[:frame+1])
                if len(drone_data) > 0:
                    drone_line.set_data(drone_data[:, 1], drone_data[:, 2])
                    drone_line.set_3d_properties(drone_data[:, 3])
                    drone_point.set_data([drone_data[-1, 1]], [drone_data[-1, 2]])
                    drone_point.set_3d_properties([drone_data[-1, 3]])
            
            # 更新动态障碍物位置和轨迹
            for i, obs_traj in enumerate(self.obstacle_trajectories):
                if frame < len(obs_traj):
                    # 显示最近的轨迹
                    recent_data = obs_traj[max(0, frame-20):frame+1]
                    if recent_data:
                        recent_array = np.array(recent_data)
                        obstacle_trails[i].set_data(recent_array[:, 1], recent_array[:, 2])
                        obstacle_trails[i].set_3d_properties(recent_array[:, 3])
                        
                        pos = obs_traj[frame]
                        obstacle_points[i].set_data([pos[1]], [pos[2]])
                        obstacle_points[i].set_3d_properties([pos[3]])
            
            return drone_line, drone_point, *obstacle_points, *obstacle_trails
        
        # 创建动画
        anim = FuncAnimation(fig, animate, frames=min(len(self.drone_trajectory), 300), 
                           interval=50, blit=True, repeat=True)
        
        plt.tight_layout()
        plt.show()
        return anim

def main():
    # 创建场景
    scene = DroneScene(gui=False)
    scene.create_obstacles(num_obstacles=15)  # 减少障碍物数量以便观察路径规划
    scene.create_targets(num_targets=3)
    scene.create_drone()
    
    # 创建高级可视化器
    visualizer = AdvancedDynamicVisualizer(scene)
    
    # 使用A*算法规划无人机路径
    targets = [tgt for tgt in scene.targets]
    visualizer.plan_drone_path(targets)
    
    # 模拟复杂的动态障碍物
    visualizer.simulate_complex_obstacle_movement(num_moving_obstacles=4, duration=8)
    
    # 创建动画
    anim = visualizer.create_advanced_animation()
    
    print("高级动画已创建，显示中...")

if __name__ == "__main__":
    main() 