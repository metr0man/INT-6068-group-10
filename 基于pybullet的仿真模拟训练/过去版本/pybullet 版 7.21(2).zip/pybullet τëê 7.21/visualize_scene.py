import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scene_creation import DroneScene

if __name__ == "__main__":
    scene = DroneScene(gui=False)
    scene.create_obstacles()
    scene.create_targets()
    scene.create_drone()

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    # 绘制障碍物（用立方体表示）
    for obs in scene.obstacles:
        x, y, z = obs['position']
        l, w, h = obs['length'], obs['width'], obs['height']
        # 画立方体的底面中心点
        ax.bar3d(x - l/2, y - w/2, 0, l, w, h, color='r', alpha=0.4, shade=True)

    # 绘制目标点
    for tgt in scene.targets:
        ax.scatter(tgt[0], tgt[1], tgt[2], color='g', s=80, label='Target')

    # 绘制起点
    ax.scatter(0, 0, 0, color='b', s=100, label='Start')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('3D 场景障碍物与目标点分布预览')
    ax.view_init(elev=30, azim=45)
    plt.tight_layout()
    plt.show() 