import os
import argparse
import time
import numpy as np
from stable_baselines3 import PPO
from massive_single_drone_env import SingleDronePathPlanningEnv
from utils import find_latest_by_steps

import pybullet as p
import pybullet_data

MODEL_DIR = "models"
BEST_MODEL_PATH = os.path.join(MODEL_DIR, "massive_single_drone_ppo_best", "best_model.zip")
MODEL_NAME = "massive_single_drone_ppo"

def select_model(model_path=None, use_best=True):
    if model_path and os.path.exists(model_path):
        print(f"[INFO] 使用指定模型: {model_path}")
        return model_path
    if use_best and os.path.exists(BEST_MODEL_PATH):
        print(f"[INFO] 使用best模型: {BEST_MODEL_PATH}")
        return BEST_MODEL_PATH
    latest = find_latest_by_steps(os.path.join(MODEL_DIR, "massive_single_drone_ppo_checkpoints"), MODEL_NAME)
    if latest:
        print(f"[INFO] 使用最新checkpoint模型: {latest}")
        return latest
    latest = find_latest_by_steps(MODEL_DIR, MODEL_NAME)
    if latest:
        print(f"[INFO] 使用根目录下最新模型: {latest}")
        return latest
    raise FileNotFoundError("未找到可用的训练模型！")

def visualize(model_path=None, episodes=3, max_steps=1000, step_delay=0.02):
    print('[DEBUG] visualize start')
    env = SingleDronePathPlanningEnv(env_id=0)
    print('[DEBUG] SingleDronePathPlanningEnv created')
    env.scene.gui = True
    env.scene.set_scene_camera()  # 固定全景摄像头
    print('[DEBUG] set_scene_camera called')
    print("[INFO] 环境初始化完成，准备加载模型...")

    model = PPO.load(model_path, env=env, device="cpu")
    print('[INFO] 模型加载完成，开始演示...')

    all_drone_traj = []
    obstacles_list = None  # 只导出一次
    targets_list = None

    for ep in range(episodes):
        print(f'[DEBUG] episode {ep+1} start')
        obs, info = env.reset()
        drone_traj = []
        total_reward = 0
        print(f"\n===== 演示回合 {ep+1}/{episodes} =====")
        # 只在第一个回合的第一个reset后导出障碍物和目标点
        if ep == 0:
            obstacles_list = []
            for obs_obj in env.scene.obstacles:
                obstacles_list.append({
                    'x': obs_obj['position'][0],
                    'y': obs_obj['position'][1],
                    'z': obs_obj['position'][2],
                    'dx': obs_obj['length'],
                    'dy': obs_obj['width'],
                    'dz': obs_obj['height'],
                })
            targets_list = []
            if hasattr(env.scene, 'targets'):
                for t in env.scene.targets:
                    if isinstance(t, dict) and 'position' in t:
                        targets_list.append(t['position'])
                    else:
                        targets_list.append(t)
        for step in range(max_steps):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = env.step(action)
            # 记录无人机轨迹
            pos = env.scene.get_drone_position()
            if pos is not None:
                drone_traj.append(list(pos))
            total_reward += reward
            env.scene.render()
            time.sleep(step_delay)
            if terminated or truncated:
                print(f"[INFO] 回合结束，步数: {step+1}, 累计奖励: {total_reward:.2f}")
                break
        else:
            print(f"[INFO] 达到最大步数，累计奖励: {total_reward:.2f}")
        print(f'[DEBUG] episode {ep+1} end')
        all_drone_traj.append(drone_traj)
    print("[INFO] 所有演示回合完成！")
    # 保存仿真数据
    import numpy as np
    np.save('drone_traj.npy', np.array(all_drone_traj, dtype=object))
    if obstacles_list is not None:
        np.save('obstacles.npy', np.array(obstacles_list, dtype=object))
    if targets_list is not None:
        np.save('targets.npy', np.array(targets_list, dtype=object))
    print('[INFO] 仿真数据已保存为 drone_traj.npy, obstacles.npy, targets.npy')
    input("按回车键关闭窗口...")  # 防止窗口一闪而过
    print('[DEBUG] visualize end')

def main():
    print('[DEBUG] main start')
    parser = argparse.ArgumentParser(description="PyBullet无人机智能体模型可视化演示（强制GUI）")
    parser.add_argument('--model_path', type=str, default=None, help='指定模型文件路径')
    parser.add_argument('--episodes', type=int, default=3, help='演示回合数')
    parser.add_argument('--max_steps', type=int, default=1000, help='每回合最大步数')
    parser.add_argument('--step_delay', type=float, default=0.02, help='每步仿真延迟（秒）')
    parser.add_argument('--use_best', action='store_true', help='优先使用best模型')
    args = parser.parse_args()

    model_path = select_model(args.model_path, use_best=args.use_best)
    print('[DEBUG] model_path selected:', model_path)
    visualize(model_path, episodes=args.episodes, max_steps=args.max_steps, step_delay=args.step_delay)
    print('[DEBUG] main end')

if __name__ == "__main__":
    main()