import pybullet as p
import pybullet_data
import time

cid = p.connect(p.GUI)
print("pybullet connect id:", cid)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.loadURDF("plane.urdf")
for i in range(1000):
    p.stepSimulation()
    time.sleep(1/240)
input("按回车退出")
p.disconnect() 