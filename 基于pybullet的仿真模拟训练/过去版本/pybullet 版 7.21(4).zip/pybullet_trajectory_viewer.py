import numpy as np
import pybullet as p
import pybullet_data
import time

# ====== 加载数据 ======
drone_traj = np.load('drone_traj.npy', allow_pickle=True)[0]  # 取第一个回合，shape=(步数, 3)
obstacles = np.load('obstacles.npy', allow_pickle=True)
targets = np.load('targets.npy', allow_pickle=True)
if hasattr(targets, 'tolist'):
    targets = np.array(targets.tolist())

print('drone_traj.shape:', drone_traj.shape)
print('obstacles:', obstacles)
print('targets:', targets)

# ====== 初始化PyBullet ======
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.resetSimulation()
p.setGravity(0, 0, -9.8)
p.loadURDF("plane.urdf")

# ====== 创建障碍物 ======
obstacle_ids = []
for obs in obstacles:
    half_extents = [obs['dx']/2, obs['dy']/2, obs['dz']/2]
    visual_shape_id = p.createVisualShape(
        shapeType=p.GEOM_BOX,
        halfExtents=half_extents,
        rgbaColor=[1, 0, 0, 0.8],
        visualFramePosition=[0, 0, 0]
    )
    collision_shape_id = p.createCollisionShape(
        shapeType=p.GEOM_BOX,
        halfExtents=half_extents,
        collisionFramePosition=[0, 0, 0]
    )
    obs_id = p.createMultiBody(
        baseMass=0,
        baseCollisionShapeIndex=collision_shape_id,
        baseVisualShapeIndex=visual_shape_id,
        basePosition=[obs['x'], obs['y'], obs['z']]
    )
    obstacle_ids.append(obs_id)

# ====== 创建目标点 ======
target_ids = []
for t in targets:
    visual_shape_id = p.createVisualShape(
        shapeType=p.GEOM_SPHERE,
        radius=1.0,
        rgbaColor=[0, 1, 0, 1],
    )
    target_id = p.createMultiBody(
        baseMass=0,
        baseVisualShapeIndex=visual_shape_id,
        basePosition=list(t)
    )
    target_ids.append(target_id)

# ====== 创建无人机（蓝色球体） ======
dr_visual_id = p.createVisualShape(
    shapeType=p.GEOM_SPHERE,
    radius=0.5,
    rgbaColor=[0, 0, 1, 1],
)
dr_collision_id = p.createCollisionShape(
    shapeType=p.GEOM_SPHERE,
    radius=0.5
)
dr_id = p.createMultiBody(
    baseMass=1,
    baseCollisionShapeIndex=dr_collision_id,
    baseVisualShapeIndex=dr_visual_id,
    basePosition=drone_traj[0].tolist()
)

# ====== 轨迹回放 ======
print('按Q键退出，按P键暂停/播放，按N键单步')
paused = False
step_mode = False
frame = 0
max_frame = len(drone_traj)

while frame < max_frame:
    keys = p.getKeyboardEvents()
    if ord('q') in keys and keys[ord('q')] & p.KEY_WAS_TRIGGERED:
        print('退出')
        break
    if ord('p') in keys and keys[ord('p')] & p.KEY_WAS_TRIGGERED:
        paused = not paused
        print('暂停' if paused else '播放')
    if ord('n') in keys and keys[ord('n')] & p.KEY_WAS_TRIGGERED:
        step_mode = True
        paused = True
        print('单步')
    if not paused or step_mode:
        # 设置无人机位置
        p.resetBasePositionAndOrientation(dr_id, drone_traj[frame].tolist(), [0, 0, 0, 1])
        frame += 1
        step_mode = False
    p.stepSimulation()
    time.sleep(1/60)

p.disconnect() 