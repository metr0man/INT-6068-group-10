import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import animation

# ====== 自动加载仿真数据 ======
drone_traj = np.load('drone_traj.npy', allow_pickle=True)
obstacles = np.load('obstacles.npy', allow_pickle=True)
targets = np.load('targets.npy', allow_pickle=True)
print('drone_traj.shape:', drone_traj.shape)
print('obstacles:', obstacles)
print('targets:', targets)
if len(drone_traj) > 0:
    drone_traj = drone_traj[0]
else:
    raise ValueError('drone_traj.npy 数据为空！')

# ====== 3D动画可视化 ======
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# 设置坐标轴范围
all_points = np.vstack([drone_traj, targets] + [np.array([[o['x'], o['y'], o['z']]]) for o in obstacles])
min_xyz = all_points.min(axis=0) - 5
max_xyz = all_points.max(axis=0) + 5
ax.set_xlim(min_xyz[0], max_xyz[0])
ax.set_ylim(min_xyz[1], max_xyz[1])
ax.set_zlim(min_xyz[2], max_xyz[2])

# 绘制障碍物（长方体）
def draw_obstacle(ax, obs):
    rx = [obs['x'] - obs['dx']/2, obs['x'] + obs['dx']/2]
    ry = [obs['y'] - obs['dy']/2, obs['y'] + obs['dy']/2]
    rz = [obs['z'] - obs['dz']/2, obs['z'] + obs['dz']/2]
    for s, e in [([rx[0], ry[0], rz[0]], [rx[1], ry[0], rz[0]]),
                 ([rx[0], ry[0], rz[0]], [rx[0], ry[1], rz[0]]),
                 ([rx[0], ry[0], rz[0]], [rx[0], ry[0], rz[1]]),
                 ([rx[1], ry[1], rz[1]], [rx[0], ry[1], rz[1]]),
                 ([rx[1], ry[1], rz[1]], [rx[1], ry[0], rz[1]]),
                 ([rx[1], ry[1], rz[1]], [rx[1], ry[1], rz[0]]),
                 ([rx[0], ry[1], rz[0]], [rx[0], ry[1], rz[1]]),
                 ([rx[0], ry[1], rz[0]], [rx[1], ry[1], rz[0]]),
                 ([rx[1], ry[0], rz[0]], [rx[1], ry[1], rz[0]]),
                 ([rx[1], ry[0], rz[0]], [rx[1], ry[0], rz[1]]),
                 ([rx[0], ry[0], rz[1]], [rx[1], ry[0], rz[1]]),
                 ([rx[0], ry[0], rz[1]], [rx[0], ry[1], rz[1]])]:
        ax.plot3D(*zip(s, e), color="red", alpha=0.6)

for obs in obstacles:
    draw_obstacle(ax, obs)

# 绘制目标点
ax.scatter(targets[:,0], targets[:,1], targets[:,2], c='g', s=60, marker='*', label='Target')

# 初始化无人机轨迹
traj_line, = ax.plot([], [], [], 'b-', lw=2, label='Drone Trajectory')
drone_dot, = ax.plot([], [], [], 'bo', markersize=8, label='Drone')

# 动画更新函数
def update(frame):
    traj_line.set_data(drone_traj[:frame+1,0], drone_traj[:frame+1,1])
    traj_line.set_3d_properties(drone_traj[:frame+1,2])
    drone_dot.set_data(drone_traj[frame,0], drone_traj[frame,1])
    drone_dot.set_3d_properties(drone_traj[frame,2])
    return traj_line, drone_dot

ani = animation.FuncAnimation(fig, update, frames=len(drone_traj), interval=50, blit=True)

ax.legend()
plt.title('3D Drone Trajectory Visualization')
plt.tight_layout()
plt.show()

# ====== 保存为mp4视频（需安装ffmpeg） ======
# ani.save('drone_3d_traj.mp4', writer='ffmpeg', fps=20)
# print('视频已保存为 drone_3d_traj.mp4') 